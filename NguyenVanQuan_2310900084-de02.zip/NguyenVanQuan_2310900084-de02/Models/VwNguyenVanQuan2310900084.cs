﻿using System;
using System.Collections.Generic;

namespace NguyenVanQuan_2310900084.Models;

public partial class VwNguyenVanQuan2310900084
{
    public string MaSv { get; set; } = null!;

    public string? Hosv { get; set; }

    public DateTime? NgaySinh { get; set; }

    public string? Phai { get; set; }

    public string? MaKhoa { get; set; }

    public string? Ten { get; set; }
}
